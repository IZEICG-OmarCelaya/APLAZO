import React from 'react';
import { VERSION } from '@twilio/flex-ui';
import { FlexPlugin } from '@twilio/flex-plugin';
import reducers, { namespace } from './states';
import CannedResponses from './CannedResponses';

const PLUGIN_NAME = 'AplazoEncuestaPlugin';

export default class AplazoEncuestaPlugin extends FlexPlugin {
  constructor() {
    super(PLUGIN_NAME);
  }

  /**
   * This code is run when your plugin is being started
   * Use this to modify any UI components or attach to the actions framework
   *
   * @param flex { typeof import('@twilio/flex-ui') }
   * @param manager { import('@twilio/flex-ui').Manager }
   */
  async init(flex, manager) {
    this.registerReducers(manager);

    flex.MessageInput.Content.add(<CannedResponses key="canned-responses1" />);
    // Mensaje de despedida
    flex.Actions.replaceAction("WrapupTask", (payload, original) => {
      // Only alter chat tasks:
      if (payload.task.taskChannelUniqueName !== "chat") {
        original(payload);
      } else {
        return new Promise(function (resolve, reject) {
          let body = `Nuestra prioridad en Aplazo es brindar el mejor servicio y tu opinión es muy importante para nosotros. Te invitamos a evaluar nuestro servicio a través de la siguiente encuesta.
          Selecciona una de las siguientes opciones:`
          if (payload.task._task.attributes.channelType === "whatsapp") {
            flex.Actions.invokeAction("SendMessage", {
              body: body,
              channelSid: payload.task.attributes.channelSid
            }).then(response => {
              // Wait until the message is sent to wrap-up the task:
              resolve(original(payload));
            });
          } else {
            resolve(original(payload));
          }
        });
      }
    });

  }

  /**
   * Registers the plugin reducers
   *
   * @param manager { Flex.Manager }
   */
  registerReducers(manager) {
    if (!manager.store.addReducer) {
      // eslint-disable-next-line
      console.error(`You need FlexUI > 1.9.0 to use built-in redux; you are currently on ${VERSION}`);
      return;
    }

    manager.store.addReducer(namespace, reducers);
  }
}

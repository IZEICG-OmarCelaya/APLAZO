import React from 'react';
import { connect } from 'react-redux';
import { Actions, withTheme } from '@twilio/flex-ui';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import './response.css';
import 'bootstrap/dist/css/bootstrap.min.css';

class CannedResponses extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      response: '',
      text: ''
    }
  }

  handleChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });

    this.setState({ text: event.target.value });
    document.querySelector(".Twilio-MessageInputArea-TextArea textarea").value = event.target.value;
  }

  render() {

    const cliente = this.props.currentTask._task ? this.props.currentTask._task.attributes.name : "{Nombre cliente}"
    const worker = this.props.currentTask._task ? this.props.currentTask._task._worker.attributes.full_name : "{Nombre Agente}"
    const script = [
      {
        header: 'Consultar duda',
        contenido: '¡Hola [nombre del usuario]! mi nombre es [nombre del asesor], ¿en qué te puedo ayudar?',
      },
      {
        header: 'Consulta adicional',
        contenido: '¿Algo más en lo que te pueda ayudar?',
      },
      {
        header: 'Departamento correspondiente',
        contenido: 'Hemos enviado tu consulta al departamento correspondiente, en un momento uno de nuestros asesores te atenderá',
      },
      {
        header: 'Incumplimiento T&Cs',
        contenido: 'Hemos recibido tu solicitud, sin embargo, hemos bloqueado tu cuenta por incumplimiento de los Términos y Condiciones que aceptaste en el momento de registrarte, por lo tanto tu cuenta quedará bloqueada de forma permanente.',
      },
      {
        header: 'Motivo de cancelación',
        contenido: 'Lamentamos saber que quieres cancelar tu cuenta Aplazo. ¿Podrías comentarnos la razón? Trabajaremos arduamente para mejorar la experiencia.'
      },
      {
        header: 'Esperamos que regreses',
        contenido: 'Hemos cancelado tu cuenta, muchas gracias por utilizar Aplazo, ¡esperamos que regreses!',
      },
      {
        header: 'Notificar próxima compra',
        contenido: '¡Gracias por continuar con Aplazo! Puedes realizar tu próxima compra y notificarnos cuando sea tu última cuota para realizarte el ajuste correspondiente, nuestro equipo de asesores estará pendiente para ayudarte.',
      },
      {
        header: 'Usuario no conoce comercios',
        contenido: '¡Hola! Gracias por contactarnos. Te informamos que todos nuestros comercios cumplen con los requerimientos para brindarte una buena experiencia, en caso de algún inconveniente podremos valorar el reembolso.'
      },
      {
        header: 'Rechazado',
        contenido: '¡Hola [Nombre]!\nEstimado usuario, hemos revisado tu documentación, te informamos que lamentablemente tu perfil no cumple los requisitos necesarios  para continuar con el proceso. \nAgradecemos tu interés.',
      },
      {
        header: "Usuario consulta por enganche",
        contenido: "¡Hola! Gracias por contactarnos. Te informamos que para entregarte tu orden, debes realizar el pago inicial, aplica para tienda física y online."
      }
    ]
    return (
      <div className="" key={"cannedResponseDiv"}>
        <Select
          className="display letra bordes css-85s8ih"
          value={this.state.response}
          onChange={this.handleChange}
          name="response"
          key={"selectCannedResponse"}
        >
          <MenuItem key="placeholder" value="placeholder" disabled>
            Quick Replies
          </MenuItem>
          {script.map((value, i) => (
            <MenuItem value={value.contenido} className="letra bordes" key={value.header}>{value.header}</MenuItem>
          ))}
        </Select>
      </div>
    )
  }
};

const mapStateToProps = (state, ownProps) => {
  let currentTask = false;
  state.flex.worker.tasks.forEach((task) => {
    if (ownProps.channelSid === task.attributes.channelSid) {
      currentTask = task;
    }
  })

  return {
    state,
    currentTask,
  }
}

export default connect(mapStateToProps)(withTheme(CannedResponses));
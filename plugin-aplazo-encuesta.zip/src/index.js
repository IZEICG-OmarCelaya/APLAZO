import * as FlexPlugin from '@twilio/flex-plugin';

import AplazoEncuestaPlugin from './AplazoEncuestaPlugin';

FlexPlugin.loadPlugin(AplazoEncuestaPlugin);

import React, { Component } from 'react'
// import PDFViewer from 'pdf-viewer-reactjs'
export default class CustomView extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visible: false
        }

    }
    render() {
        return (
            <div style={{position: 'absolute', width: '100%', height:'100%'}}>
                <object
                data={"https://twilio-functions-4744.twil.io/Manual%20de%20usuario%20Odessa.pdf"}
                type={"application/pdf"}
                width={"100%"}
                height="100%"
                >
                    <br/>
                    <a>Tu dispositivo</a>
                </object>
            </div>
        )
    }
}

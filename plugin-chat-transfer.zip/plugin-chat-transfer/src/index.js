import * as FlexPlugin from '@twilio/flex-plugin';

import ChatTransferPlugin from './ChatTransferPlugin';

FlexPlugin.loadPlugin(ChatTransferPlugin);

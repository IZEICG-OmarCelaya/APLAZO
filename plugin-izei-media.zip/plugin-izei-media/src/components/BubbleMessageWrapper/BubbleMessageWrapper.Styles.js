import styled from 'react-emotion';

export const BubbleMessageWrapperDiv = styled('div')`
  padding: '5px';
  margin: '0px';
`;

import styled from 'react-emotion';

export const ButtonWrapper = styled('div')`
  display: flex;
  flex-direction: 'horizontal';
`;

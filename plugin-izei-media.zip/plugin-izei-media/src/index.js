import * as FlexPlugin from '@twilio/flex-plugin';

import IzeiMediaPlugin from './IzeiMediaPlugin';

FlexPlugin.loadPlugin(IzeiMediaPlugin);

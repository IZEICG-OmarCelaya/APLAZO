import React, { Component } from 'react'


import 'bootstrap/dist/css/bootstrap.min.css';
import * as Flex from "@twilio/flex-ui";
import { Icon } from '@twilio/flex-ui-core';
import Popover from "@material-ui/core/Popover";
import { StyledButton } from './styles';
import { connect } from 'react-redux';
import { Actions, withTheme } from '@twilio/flex-ui';

class Outbound extends Component {
    constructor(props) {
        super(props);
        this.state = {
            anchorEl: null,
            open: false,
            id: undefined,
            code: '',
            contactos: [{ friendlyName: '', sid: '' }]
        }
        // this.contacto();

        this.handleClick = this.handleClick.bind(this);
        this.handleClose = this.handleClose.bind(this);
    }

    async handleClick(event) {
        this.setState({ anchorEl: event.currentTarget, open: Boolean(event.currentTarget), id: "simple-popover" });

    }

    handleClose(event) {
        this.setState({ anchorEl: event.currentTarget, open: false, id: undefined });
    }
    updateInputValue(evt) {
        this.setState({
            code: evt.target.value
        });
    }
    handleSelectChange() {

    }
    handleclick() {

    }
    render() {
        // for (let x in this.props) { console.log("IZEI-LOG: " + x); }
        return (
            <>
                <StyledButton
                    type="button"
                    classNam="btn btn-secondary"
                    disabled={false}
                    title="Tipificacion"
                    aria-describedby={this.id}
                    variant="contained"
                    onClick={this.handleClick}
                >
                    {/* Tipificacion */}
                    <Icon icon="DirectoryBold" />
                </StyledButton>
                <Popover
                    id={this.id}
                    open={this.state.open}
                    anchorEl={this.state.anchorEl}
                    onClose={this.handleClose}
                    anchorOrigin={{
                        vertical: "bottom",
                        horizontal: "center"
                    }}
                    transformOrigin={{
                        vertical: "top",
                        horizontal: "center"
                    }}
                >
                    <div className="container">
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">Outbound CALL</th>
                                </tr>
                            </thead>
                            <tbody>
                                <div >
                                    <input autocomplete="off" class="flex-md-33 flex-md-18 flex-md-36 flex-md-21" id="dialer-phone-input" type="tel" value="+5216442352465"></input>
                                    <select
                                        className="form-select mt-2"
                                        aria-label="Default select example"
                                        key="select-tipificacion"
                                        onChange={this.handleSelectChange}>
                                        <option selected>Selecciona numero outbound</option>
                                        <option value="1">+12053950257</option>
                                        <option value="2">+14155392639</option>
                                    </select>
                                    <button
                                        class="Twilio-IconButton css-12pao5j"
                                        disabled=""
                                        data-test="outbound-dialer-submit">
                                        <div class="Twilio-Icon Twilio-Icon-Call  css-y8bnhq">
                                            <svg width="1em" height="1em" viewBox="0 0 24 24" class="Twilio-Icon-Content">
                                                <path d="M6.924 4.57a.29.29 0 00-.116.023.621.621 0 00-.1.054c-.431.308-.84.652-1.225 1.032-.385.38-.608.658-.67.832.02.463.136.969.347 1.518.21.55.51 1.132.901 1.749.39.616.866 1.263 1.425 1.941a32.29 32.29 0 001.903 2.095c.72.72 1.42 1.359 2.103 1.918.683.56 1.333 1.033 1.95 1.418.615.385 1.198.685 1.748.901.55.216 1.055.334 1.517.355.175-.072.452-.3.832-.686.38-.385.724-.794 1.033-1.225a.292.292 0 00.069-.139.817.817 0 00.008-.092 28.76 28.76 0 00-.601-.4c-.298-.196-.617-.406-.956-.632l-1.525-1.017h-.015a.65.65 0 00-.108.015.654.654 0 00-.2.093 27.775 27.775 0 00-1.371.77l-.555.308-.509-.37c-.184-.133-.485-.37-.9-.708a21.965 21.965 0 01-1.565-1.449 28.089 28.089 0 01-1.456-1.571c-.344-.41-.583-.714-.716-.909l-.354-.508.308-.54c.195-.349.362-.644.5-.886.14-.241.229-.403.27-.485a.813.813 0 00.092-.323c-.061-.103-.19-.303-.385-.601a97.481 97.481 0 00-.624-.94 97.48 97.48 0 01-.624-.94 11.001 11.001 0 00-.4-.585c0-.01-.005-.016-.016-.016h-.015zm.01-.96c.165 0 .319.03.463.092a.753.753 0 01.338.277l.378.554c.21.309.436.645.678 1.01.241.364.467.703.678 1.016.21.314.341.511.393.594a.999.999 0 01.123.57c-.01.226-.077.462-.2.708-.072.124-.196.34-.37.648-.175.308-.313.56-.416.754.113.165.331.442.655.832.323.39.788.889 1.394 1.495.616.616 1.12 1.086 1.51 1.41.39.323.667.541.832.654.185-.102.434-.244.747-.423.313-.18.532-.3.655-.362.133-.072.264-.126.393-.162.128-.036.254-.054.377-.054.093 0 .18.013.262.038.082.026.16.06.231.1l.609.393a373.833 373.833 0 012.041 1.348c.308.206.493.334.555.386.205.133.331.352.377.655.046.303-.038.613-.254.932l-.277.362c-.185.241-.411.506-.678.793a7.786 7.786 0 01-.855.794c-.303.241-.573.362-.81.362h-.015c-.677-.02-1.376-.185-2.095-.493a13.117 13.117 0 01-2.126-1.164 19.865 19.865 0 01-2.026-1.556 36.632 36.632 0 01-1.795-1.671 34.26 34.26 0 01-1.664-1.795 20.545 20.545 0 01-1.548-2.026A13.27 13.27 0 014.33 8.562c-.309-.713-.473-1.404-.493-2.072-.01-.246.105-.519.346-.816.242-.298.506-.58.794-.848.287-.267.552-.493.793-.678.241-.185.367-.282.378-.292.123-.083.251-.144.385-.185.133-.041.267-.062.4-.062z"
                                                    fill="currentColor"
                                                    stroke="none"
                                                    stroke-width="1"
                                                    fill-rule="evenodd">
                                                </path>
                                            </svg>
                                        </div>
                                    </button>
                                </div>
                            </tbody>
                        </table>
                    </div>
                </Popover>
            </>
        );
    }
}
const mapStateToProps = (state, ownProps) => {
    let currentTask = false;
    state.flex.worker.tasks.forEach((task) => {
        if (ownProps.channelSid === task.attributes.channelSid) {
            currentTask = task;
        }
    })

    return {
        state,
        currentTask,
    }
}

export default connect(mapStateToProps)(withTheme(Outbound));

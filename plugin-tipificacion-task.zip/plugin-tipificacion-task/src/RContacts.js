import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import * as Flex from "@twilio/flex-ui";
import { connect } from 'react-redux';
import { Actions, withTheme } from '@twilio/flex-ui';
import "./style.css"
import Select from 'react-select';

class Contacts extends Component {
    constructor(props) {
        super(props);

        this.state = {
            anchorEl: null,
            open: false,
            id: undefined,
            code: '',
            contactos: [{ friendlyName: '', sid: '' }],
            selectNumber: ""
        }
        // this.contacto();

        this.handleClick = this.handleClick.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.updateTask = this.updateTask.bind(this);
        this.handleSelectChange = this.handleSelectChange.bind(this);
    }

    async handleClick(event) {
        this.setState({ anchorEl: event.currentTarget, open: Boolean(event.currentTarget), id: "simple-popover" });
        // await this.contacto();
        // await this.props.task.setAttributes({
        //     ...this.props.task.attributes,
        //     Tipificacion: "Nueva Seleccion",
        // })
    }

    handleClose(event) {
        this.setState({ anchorEl: event.currentTarget, open: false, id: undefined });
    }
    updateInputValue(evt) {
        this.setState({
            code: evt.target.value
        });
    }
    handleSelectChange() {

    }
    handleSelectChange(value) {
        this.setState({ selectNumber: value.vale });
    }
    async updateTask() {
        console.log("IZEI-LOG: NO UPDATE TASK")
        if (this.props) {
            console.log("IZEI-LOG: UPDATE TASK")
            await this.props.task.setAttributes({
                ...this.props.task.attributes,
                Tipificacion: this.state.selectNumber,
            })
        }
    }

    render() {
        // for(let x in this.props.task) { console.log("IZEI-LOG: "+x);}
        const supliers = [
            { label: "Desglose de pago", vale: "Desglose_de_pago" },
            { label: "Pago pendiente", vale: "Pago_pendiente" },
            { label: "Pago incompleto", vale: "Pago_incompleto" },
            { label: "Factura de pago", vale: "Factura_de_pago" },
            { label: "Nota de crédito", vale: "Nota_de_crédito" },
            { label: "Pagó a otra cuenta bancaria", vale: "Pagó_a_otra_cuenta_bancaria" },
            { label: "Comisiones", vale: "Comisiones" },
            { label: "Darse de alta en plataforma", vale: "Darse_de_alta_en_plataforma" },
            { label: "Darse de baja en plataforma", vale: "Darse_de_baja_en_plataforma" },
            { label: "Consulta sobre plug-in", vale: "Consulta_sobre_plug-in" },
            { label: "Olvidó contraseña", vale: "Olvidó_contraseña" },
            { label: "Actualizar datos de contacto", vale: "Cambio_de_razón_social" },
            { label: "Pago incompleto", vale: "Actualizar_datos_de_contacto" },
            { label: "Cambiar información bancaria y tax", vale: "Cambio_información_bancaria" },
            { label: "No visualiza orden PosUI" , vale: "No_visualiza_orden_PosUI"},
            { label: "No visualiza orden e-commerce" , vale: "No_visualiza_orden_e-commerce"},
            { label: "No visualiza orden en admin" , vale: "No_visualiza_orden_en_admin"},
            { label: "Promociones de otros comercios" , vale: "Promociones_de_otros_comercios"},
            { label: "Error en promociones" , vale: "Error_en_promociones"},
            { label: "Promociones disponibles en su negocio" , vale: "Promoción_disponible_negocio"},
            { label: "Actualizar datos bancarios fiscales" , vale: "Act_datos_bancarios_fiscales"},
            { label: "Solicita informes" , vale: "Solicita_informes"},
            { label: "Error en factura" , vale: "Error_en_factura"},
            { label: "Problema con API" , vale: "Problema_con_API"}
        ]
        return (
            <>
                <table className="table table-hover mt-5">
                    <thead>
                        <tr>
                            <th scope="col">Tipificacion</th>
                        </tr>
                    </thead>
                    <tbody>
                        <div >
                            <Select
                                className="mt-2 mb-4"
                                defaultValue={supliers[0]}
                                options={supliers}
                                key="select-tipificacion"
                                onChange={this.handleSelectChange}>
                            </Select>
                            <button
                                className="Twilio-Button css-1v71t91 ms-5"
                                onClick={this.updateTask}
                            ><span className="Twilio">Aceptar</span></button>
                        </div>
                    </tbody>
                </table>
            </>
        );
    }
}
const mapStateToProps = (state, ownProps) => {
    let currentTask = false;
    state.flex.worker.tasks.forEach((task) => {
        if (ownProps.channelSid === task.attributes.channelSid) {
            currentTask = task;
        }
    })

    return {
        state,
        currentTask,
    }
}

export default connect(mapStateToProps)(withTheme(Contacts));

{/* <select
className="form-select selec"
aria-label="Default select example"
key="select-tipificacion"
onChange={this.handleSelectChange}>
<option selected>Open this select menu</option>
<option value="1">Error_en_registro</option>
<option value="2">Error_de_pago</option>
<option value="3">Devolucion_no_realizada</option>
</select> */}
import React, { Component } from 'react'
import { connect } from 'react-redux';
import { Actions, withTheme } from '@twilio/flex-ui';
import 'bootstrap/dist/css/bootstrap.min.css';

class Tipificacion extends Component {
  constructor(props) {
    super(props);
    this.state = {
      response: ''
    }
    // for(let x in props.currentTask._task._worker.attributes) { console.log("IZEI-LOG: "+x);}
    // console.log("IZEI-LOG: "+props.currentTask._task.attributes.name)
    // console.log("IZEI-LOG: "+props.currentTask._task._worker.attributes.full_name)
  }

  async updateTask(task) {
    console.log("IZEI-LOG: UPDATE TASK")
    await task.setAttributes({
      ...task._task.attributes,
      Tipificacion: "Nueva tipificacion",
    })
  }

  render() {
    // for (let x in this.props.task.setAttributes) { console.log("IZEI-LOG: " + x); }
    // console.log("IZEI-LOG: "+this.props.currentTask);
    // this.props.task.setAttributes({
    //   ...this.props.task._task.attributes,
    //   Tipificacion: "Nueva Tipificacion",
    // })
    return (
      <div >
        <select className="form-select" aria-label="Default select example">
          <option selected>Open this select menu</option>
          <option value="1">Error_en_registro</option>
          <option value="2">Error_de_pago</option>
          <option value="3">Devolucion_no_realizada</option>
        </select>
        <button
          type="button"
          className="btn btn-light  mt-4"
          onClick={this.updateTask(this.props.task)}
        >Aceptar</button>
      </div>
    )
  }
}

const mapStateToProps = (state, ownProps) => {
  let currentTask = false;
  state.flex.worker.tasks.forEach((task) => {
    if (ownProps.channelSid === task.attributes.channelSid) {
      currentTask = task;
    }
  })

  return {
    state,
    currentTask,
  }
}

export default connect(mapStateToProps)(withTheme(Tipificacion));
import * as FlexPlugin from '@twilio/flex-plugin';

import TipificacionTaskPlugin from './TipificacionTaskPlugin';

FlexPlugin.loadPlugin(TipificacionTaskPlugin);
